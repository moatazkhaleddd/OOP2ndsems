import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Project extends JFrame implements ActionListener {
    Project() {
        setSize(1500, 730);

        ImageIcon i1 = new ImageIcon("C:\\Users\\amrk9\\Downloads\\Photos\\22017-MTSU+KOM+&+RH-EXT+01.jpg");
        Image i2 = i1.getImage().getScaledInstance(1500, 750, Image.SCALE_SMOOTH);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        add(image);

        JMenuBar mb = new JMenuBar();
        mb.setBackground(new Color(48, 48, 48));

        JMenu newInformation = new JMenu("New Information");
        newInformation.setForeground(Color.WHITE);
        mb.add(newInformation);

        JMenuItem facultyInfo = new JMenuItem("New Faculty Information");
        facultyInfo.setBackground(new Color(64, 64, 64));
        facultyInfo.setForeground(Color.WHITE);
        facultyInfo.addActionListener(this);
        newInformation.add(facultyInfo);

        JMenuItem studentInfo = new JMenuItem("New Student Information");
        studentInfo.setBackground(new Color(64, 64, 64));
        studentInfo.setForeground(Color.WHITE);
        studentInfo.addActionListener(this);
        newInformation.add(studentInfo);

        JMenu Details = new JMenu("View Details");
        Details.setForeground(Color.WHITE);
        mb.add(Details);

        JMenuItem facultydetails = new JMenuItem("View Faculty Details");
        facultydetails.setBackground(new Color(64, 64, 64));
        facultydetails.setForeground(Color.WHITE);
        facultydetails.addActionListener(this);
        Details.add(facultydetails);

        JMenuItem studentdetails = new JMenuItem("View Student Details");
        studentdetails.setBackground(new Color(64, 64, 64));
        studentdetails.setForeground(Color.WHITE);
        studentdetails.addActionListener(this);
        Details.add(studentdetails);

        JMenu courses = new JMenu("Courses");
        courses.setForeground(Color.WHITE);
        mb.add(courses);

        JMenuItem studentCourses = new JMenuItem("Student Courses");
        studentCourses.setBackground(new Color(64, 64, 64));
        studentCourses.setForeground(Color.WHITE);
        studentCourses.addActionListener(this);
        courses.add(studentCourses);

        JMenuItem studentCoursesDetails = new JMenuItem("Student Courses Details");
        studentCoursesDetails.setBackground(new Color(64, 64, 64));
        studentCoursesDetails.setForeground(Color.WHITE);
        studentCoursesDetails.addActionListener(this);
        courses.add(studentCoursesDetails);


        JMenu Attend = new JMenu("Apply Attendance");
        Attend.setForeground(Color.WHITE);
        mb.add(Attend);

        JMenuItem facultyleave = new JMenuItem("Faculty Attend");
        facultyleave.setBackground(new Color(64, 64, 64));
        facultyleave.setForeground(Color.WHITE);
        facultyleave.addActionListener(this);
        Attend.add(facultyleave);

        JMenuItem studentattend = new JMenuItem("Student Attend");
        studentattend.setBackground(new Color(64, 64, 64));
        studentattend.setForeground(Color.WHITE);
        studentattend.addActionListener(this);
        Attend.add(studentattend);

        JMenu AttendanceDetails = new JMenu("Attendance Details");
        AttendanceDetails.setForeground(Color.WHITE);
        mb.add(AttendanceDetails);

        JMenuItem facultyattenddetails = new JMenuItem("Faculty Attend Details");
        facultyattenddetails.setBackground(new Color(64, 64, 64));
        facultyattenddetails.setForeground(Color.WHITE);
        facultyattenddetails.addActionListener(this);
        AttendanceDetails.add(facultyattenddetails);

        JMenuItem studentattenddetails = new JMenuItem("Student Attend Details");
        studentattenddetails.setBackground(new Color(64, 64, 64));
        studentattenddetails.setForeground(Color.WHITE);
        studentattenddetails.addActionListener(this);
        AttendanceDetails.add(studentattenddetails);

        JMenu exam = new JMenu("Examination");
        exam.setForeground(Color.WHITE);
        mb.add(exam);

        JMenuItem examinationdetails = new JMenuItem("Examination Results");
        examinationdetails.setBackground(new Color(64, 64, 64));
        examinationdetails.setForeground(Color.WHITE);
        examinationdetails.addActionListener(this);
        exam.add(examinationdetails);

        JMenuItem entermarks = new JMenuItem("Enter Marks");
        entermarks.setBackground(new Color(64, 64, 64));
        entermarks.setForeground(Color.WHITE);
        entermarks.addActionListener(this);
        exam.add(entermarks);

        JMenu updateinfo = new JMenu("Update Details");
        updateinfo.setForeground(Color.WHITE);
        mb.add(updateinfo);

        JMenuItem updatefacultyinfo = new JMenuItem("Update Faculty Details");
        updatefacultyinfo.setBackground(new Color(64, 64, 64));
        updatefacultyinfo.setForeground(Color.WHITE);
        updatefacultyinfo.addActionListener(this);
        updateinfo.add(updatefacultyinfo);

        JMenuItem updatestudentinfo = new JMenuItem("Update Student Details");
        updatestudentinfo.setBackground(new Color(64, 64, 64));
        updatestudentinfo.setForeground(Color.WHITE);
        updatestudentinfo.addActionListener(this);
        updateinfo.add(updatestudentinfo);

        JMenu fee = new JMenu("Fee Details");
        fee.setForeground(Color.WHITE);
        mb.add(fee);

        JMenuItem feestructure = new JMenuItem("Fee Structure");
        feestructure.setBackground(new Color(64, 64, 64));
        feestructure.setForeground(Color.WHITE);
        feestructure.addActionListener(this);
        fee.add(feestructure);

        JMenuItem feeform = new JMenuItem("Fee Student Form");
        feeform.setBackground(new Color(64, 64, 64));
        feeform.setForeground(Color.WHITE);
        feeform.addActionListener(this);
        fee.add(feeform);

        JMenu utility = new JMenu("Utility");
        utility.setForeground(Color.WHITE);
        mb.add(utility);

        JMenuItem notepad = new JMenuItem("Notepad");
        notepad.setBackground(new Color(64, 64, 64));
        notepad.setForeground(Color.WHITE);
        notepad.addActionListener(this);
        utility.add(notepad);

        JMenuItem gpaCalc = new JMenuItem("GPA Calculator");
        gpaCalc.setBackground(new Color(64, 64, 64));
        gpaCalc.setForeground(Color.WHITE);
        gpaCalc.addActionListener(this);
        utility.add(gpaCalc);

        JMenuItem lms = new JMenuItem("Library Management System");
        lms.setBackground(new Color(64, 64, 64));
        lms.setForeground(Color.WHITE);
        lms.addActionListener(this);
        utility.add(lms);

        JMenu exit = new JMenu("Exit");
        exit.setForeground(Color.WHITE);
        mb.add(exit);

        JMenuItem ex = new JMenuItem("Exit");
        ex.setBackground(new Color(64, 64, 64));
        ex.setForeground(Color.WHITE);
        ex.addActionListener(this);
        exit.add(ex);

        setJMenuBar(mb);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String msg = ae.getActionCommand();
        switch (msg) {
            case "Exit":
                setVisible(false);
                break;
            case "GPA Calculator":
                new GPACALC();
                break;
            case "Notepad":
                try {
                    Runtime.getRuntime().exec("notepad.exe");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case "New Faculty Information":
                new AddTeacher();
                break;
            case "New Student Information":
                new AddStudent();
                break;
            case "View Faculty Details":
                new TeacherDetails();
                break;
            case "View Student Details":
                new StudentDetails();
                break;
            case "Faculty Attend":
                new TeacherAttend();
                break;
            case "Student Attend":
                new StudentAttend();
                break;
            case "Faculty Attend Details":
                new TeacherAttendDetails();
                break;
            case "Student Attend Details":
                new StudentAttendDetails();
                break;
            case "Student Courses":
                new StudentCourseApplication();
                break;
            case "Student Courses Details":
                new StudentCourseApplicationDetails();
                break;
            case "Update Faculty Details":
                new UpdateTeacher();
                break;
            case "Update Student Details":
                new UpdateStudent();
                break;
            case "Enter Marks":
                new EnterMarks();
                break;
            case "Examination Results":
                new ExaminationDetails();
                break;
            case "Library Management System":
                new LMSGUI();
                break;
            case "Fee Structure":
                new FeeStructure();
                break;
            case "Fee Student Form":
                new StudentFeeForm();
                break;
            default:
                System.out.println("Invalid option selected: " + msg);
                break;
        }
    }

    public static void main(String[] args) {
        new Project();
    }
}