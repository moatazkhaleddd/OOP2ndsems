
//عاملها ب CHATGPT



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class LMSGUI extends JFrame implements ActionListener {
    private int maxBooks;
    private ArrayList<String> bookTitles;
    private ArrayList<String> bookDescriptions;
    private ArrayList<Boolean> bookIssued;

    private JTextField titleField, descriptionField, idField, maxBooksField;
    private JTextArea outputArea;
    private JButton addButton, issueButton, returnButton, deleteButton, editButton, viewButton, searchButton, setMaxBooksButton;

    public LMSGUI() {
        setTitle("Library Management System");
        setSize(600, 500);
        setLayout(new BorderLayout());

        bookTitles = new ArrayList<>();
        bookDescriptions = new ArrayList<>();
        bookIssued = new ArrayList<>();

        JPanel topPanel = new JPanel(new GridLayout(4, 2));
        topPanel.add(new JLabel("Max Books:"));
        maxBooksField = new JTextField();
        topPanel.add(maxBooksField);

        topPanel.add(new JLabel("Title:"));
        titleField = new JTextField();
        topPanel.add(titleField);

        topPanel.add(new JLabel("Description:"));
        descriptionField = new JTextField();
        topPanel.add(descriptionField);

        topPanel.add(new JLabel("Book ID:"));
        idField = new JTextField();
        topPanel.add(idField);

        add(topPanel, BorderLayout.NORTH);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new GridLayout(2, 4));
        setMaxBooksButton = new JButton("Set Max Books");
        setMaxBooksButton.addActionListener(this);
        bottomPanel.add(setMaxBooksButton);

        addButton = new JButton("Add Book");
        addButton.addActionListener(this);
        bottomPanel.add(addButton);

        searchButton = new JButton("Search Book");
        searchButton.addActionListener(this);
        bottomPanel.add(searchButton);

        issueButton = new JButton("Issue Book");
        issueButton.addActionListener(this);
        bottomPanel.add(issueButton);

        returnButton = new JButton("Return Book");
        returnButton.addActionListener(this);
        bottomPanel.add(returnButton);

        deleteButton = new JButton("Delete Book");
        deleteButton.addActionListener(this);
        bottomPanel.add(deleteButton);

        editButton = new JButton("Edit Book");
        editButton.addActionListener(this);
        bottomPanel.add(editButton);

        viewButton = new JButton("View All Books");
        viewButton.addActionListener(this);
        bottomPanel.add(viewButton);

        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == setMaxBooksButton) {
                maxBooks = Integer.parseInt(maxBooksField.getText());
                outputArea.setText("Max books set to: " + maxBooks);
            } else if (e.getSource() == addButton) {
                if (bookTitles.size() >= maxBooks) {
                    outputArea.setText("Library is full! Cannot add more books.");
                } else {
                    String title = titleField.getText();
                    String description = descriptionField.getText();
                    if (title.isEmpty()) {
                        outputArea.setText("Title cannot be empty!");
                        return;
                    }
                    bookTitles.add(title);
                    bookDescriptions.add(description);
                    bookIssued.add(false);
                    outputArea.setText("Book added successfully!");
                }
            } else if (e.getSource() == searchButton) {
                String idText = idField.getText();
                if (idText.isEmpty()) {
                    outputArea.setText("Enter Book ID to search.");
                    return;
                }
                int id = Integer.parseInt(idText) - 1;
                if (id >= 0 && id < bookTitles.size()) {
                    String status = bookIssued.get(id) ? "Issued" : "Available";
                    outputArea.setText("Title: " + bookTitles.get(id) + "\nDescription: " + bookDescriptions.get(id) + "\nStatus: " + status);
                } else {
                    outputArea.setText("Invalid Book ID.");
                }
            } else if (e.getSource() == issueButton) {
                String idText = idField.getText();
                if (idText.isEmpty()) {
                    outputArea.setText("Enter Book ID to issue.");
                    return;
                }
                int id = Integer.parseInt(idText) - 1;
                if (id >= 0 && id < bookTitles.size()) {
                    if (!bookIssued.get(id)) {
                        bookIssued.set(id, true);
                        outputArea.setText("Book issued: " + bookTitles.get(id));
                    } else {
                        outputArea.setText("Book is already issued.");
                    }
                } else {
                    outputArea.setText("Invalid Book ID.");
                }
            } else if (e.getSource() == returnButton) {
                String idText = idField.getText();
                if (idText.isEmpty()) {
                    outputArea.setText("Enter Book ID to return.");
                    return;
                }
                int id = Integer.parseInt(idText) - 1;
                if (id >= 0 && id < bookTitles.size()) {
                    if (bookIssued.get(id)) {
                        bookIssued.set(id, false);
                        outputArea.setText("Book returned: " + bookTitles.get(id));
                    } else {
                        outputArea.setText("Book was not issued.");
                    }
                } else {
                    outputArea.setText("Invalid Book ID.");
                }
            } else if (e.getSource() == deleteButton) {
                String idText = idField.getText();
                if (idText.isEmpty()) {
                    outputArea.setText("Enter Book ID to delete.");
                    return;
                }
                int id = Integer.parseInt(idText) - 1;
                if (id >= 0 && id < bookTitles.size()) {
                    bookTitles.remove(id);
                    bookDescriptions.remove(id);
                    bookIssued.remove(id);
                    outputArea.setText("Book deleted successfully.");
                } else {
                    outputArea.setText("Invalid Book ID.");
                }
            } else if (e.getSource() == editButton) {
                String idText = idField.getText();
                if (idText.isEmpty()) {
                    outputArea.setText("Enter Book ID to edit.");
                    return;
                }
                int id = Integer.parseInt(idText) - 1;
                if (id >= 0 && id < bookTitles.size()) {
                    String newTitle = titleField.getText();
                    String newDescription = descriptionField.getText();
                    if (!newTitle.isEmpty()) bookTitles.set(id, newTitle);
                    if (!newDescription.isEmpty()) bookDescriptions.set(id, newDescription);
                    outputArea.setText("Book details updated.");
                } else {
                    outputArea.setText("Invalid Book ID.");
                }
            } else if (e.getSource() == viewButton) {
                if (bookTitles.isEmpty()) {
                    outputArea.setText("No books in the library.");
                } else {
                    StringBuilder sb = new StringBuilder("Books in the library:\n");
                    for (int i = 0; i < bookTitles.size(); i++) {
                        String status = bookIssued.get(i) ? "Issued" : "Available";
                        sb.append("ID: ").append(i + 1).append(" | Title: ").append(bookTitles.get(i)).append(" | Status: ").append(status).append("\n");
                    }
                    outputArea.setText(sb.toString());
                }
            }
        } catch (NumberFormatException ex) {
            outputArea.setText("Invalid input. Please enter numbers where required.");
        }
    }

    public static void main(String[] args) {
        new LMSGUI();
    }
}