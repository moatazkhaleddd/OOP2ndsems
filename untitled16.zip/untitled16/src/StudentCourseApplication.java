import javax.swing.*;
import java.awt.*;
import java.sql.ResultSet;
import java.awt.event.*;
import java.util.ArrayList;

public class StudentCourseApplication extends JFrame implements ActionListener {
    Choice crollno;
    JList<String> courseList;
    JButton submit, cancel;

    StudentCourseApplication() {
        setSize(500, 600);
        setLocation(550, 100);
        setLayout(null);

        getContentPane().setBackground(Color.WHITE);
        JLabel lblrollno = new JLabel("Apply for Courses (Student)");
        lblrollno.setBounds(40, 20, 300, 30);
        lblrollno.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(lblrollno);

        JLabel heading = new JLabel("Search by ID");
        heading.setBounds(40, 70, 100, 20);
        add(heading);

        crollno = new Choice();
        crollno.setBounds(150, 70, 200, 20);
        add(crollno);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM student");
            while (rs.next()) {
                crollno.add(rs.getString("rollno"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        JLabel lblcourses = new JLabel("Select Courses (Max 5)");
        lblcourses.setBounds(40, 120, 200, 20);
        lblcourses.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(lblcourses);

        String[] courses = {
                "Algebra", "Calculus", "Intro to AI", "Prog I", "Prog II",
                "Data Science", "Data Structure", "Discrete", "Innovation",
                "Probability", "Math 0", "Math One"
        };

        courseList = new JList<>(courses);
        courseList.setVisibleRowCount(5); // Display 5 items before scrolling
        JScrollPane scrollPane = new JScrollPane(courseList);
        scrollPane.setBounds(40, 160, 400, 120);
        add(scrollPane);

        submit = new JButton("Submit");
        submit.setBounds(100, 320, 100, 25);
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        submit.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(submit);

        cancel = new JButton("Cancel");
        cancel.setBounds(250, 320, 100, 25);
        cancel.setBackground(Color.BLACK);
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        cancel.setFont(new Font("Tahoma", Font.BOLD, 15));
        add(cancel);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submit) {
            String rollno = crollno.getSelectedItem();
            ArrayList<String> selectedCourses = new ArrayList<>(courseList.getSelectedValuesList());

            if (selectedCourses.size() > 5) {
                JOptionPane.showMessageDialog(null, "You can select up to 5 courses only.");
                return;
            }

            try {
                Conn c = new Conn();
                for (String course : selectedCourses) {
                    String query = "INSERT INTO `student_courses` (rollno, course) VALUES ('" + rollno + "', '" + course + "')";
                    c.s.executeUpdate(query);
                }
                JOptionPane.showMessageDialog(null, "Courses Applied Successfully");
                setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new StudentCourseApplication();
    }
}