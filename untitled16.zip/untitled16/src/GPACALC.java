import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;

public class GPACALC extends JFrame implements ActionListener {
    JTextField tfSubjects, tfGrades, tfCredits, tfResult;
    JButton calculate, clear;

    private final HashMap<String, Double> letterToGPA = new HashMap<>();

    GPACALC() {
        letterToGPA.put("A+", 4.0);
        letterToGPA.put("A", 4.0);
        letterToGPA.put("A-", 3.7);
        letterToGPA.put("B+", 3.3);
        letterToGPA.put("B", 3.0);
        letterToGPA.put("B-", 2.7);
        letterToGPA.put("C+", 2.3);
        letterToGPA.put("C", 2.0);
        letterToGPA.put("C-", 1.7);
        letterToGPA.put("D+", 1.3);
        letterToGPA.put("D", 1.0);
        letterToGPA.put("F", 0.0);

        setSize(500, 400);
        setLocation(500, 200);
        setLayout(new GridLayout(5, 2, 10, 10));

        JLabel lblSubjects = new JLabel("Number of Subjects:");
        tfSubjects = new JTextField();
        add(lblSubjects);
        add(tfSubjects);

        JLabel lblGrades = new JLabel("Grades (comma-separated, e.g., A+,B,C):");
        tfGrades = new JTextField();
        add(lblGrades);
        add(tfGrades);

        JLabel lblCredits = new JLabel("Credits (comma-separated, e.g., 3,4,2):");
        tfCredits = new JTextField();
        add(lblCredits);
        add(tfCredits);

        JLabel lblResult = new JLabel("GPA:");
        tfResult = new JTextField();
        tfResult.setEditable(false);
        add(lblResult);
        add(tfResult);

        calculate = new JButton("Calculate");
        clear = new JButton("Clear");
        calculate.addActionListener(this);
        clear.addActionListener(this);

        add(calculate);
        add(clear);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == calculate) {
            try {
                int numSubjects = Integer.parseInt(tfSubjects.getText());
                String[] gradesStr = tfGrades.getText().split(",");
                String[] creditsStr = tfCredits.getText().split(",");

                if (gradesStr.length != numSubjects || creditsStr.length != numSubjects) {
                    JOptionPane.showMessageDialog(this, "Please ensure the number of grades and credits matches the number of subjects.");
                    return;
                }

                double totalPoints = 0;
                double totalCredits = 0;

                for (int i = 0; i < numSubjects; i++) {
                    String grade = gradesStr[i].trim().toUpperCase();
                    double credit = Double.parseDouble(creditsStr[i].trim());


                    if (!letterToGPA.containsKey(grade)) {
                        JOptionPane.showMessageDialog(this, "Invalid grade: " + grade);
                        return;
                    }

                    double gpaValue = letterToGPA.get(grade);
                    totalPoints += gpaValue * credit;
                    totalCredits += credit;
                }

                double gpa = totalPoints / totalCredits;
                tfResult.setText(String.format("%.2f", gpa));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please try again.");
            }
        } else if (ae.getSource() == clear) {
            tfSubjects.setText("");
            tfGrades.setText("");
            tfCredits.setText("");
            tfResult.setText("");
        }
    }

    public static void main(String[] args) {
        new GPACALC();
    }
}