import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import java.util.LinkedHashMap;

public class StudentCourseApplicationDetails extends JFrame implements ActionListener {

    Choice crollno;
    JTable table;
    JButton search, print, cancel;

    StudentCourseApplicationDetails() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Search by ID");
        heading.setBounds(20, 20, 150, 20);
        add(heading);

        crollno = new Choice();
        crollno.setBounds(180, 20, 150, 20);
        add(crollno);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM student");
            while (rs.next()) {
                crollno.add(rs.getString("rollno"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        table = new JTable();

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT * FROM student_courses");
            table.setModel(buildGroupedTableModel(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(0, 100, 900, 600);
        add(jsp);

        search = new JButton("Search");
        search.setBounds(20, 70, 80, 20);
        search.addActionListener(this);
        add(search);

        print = new JButton("Print");
        print.setBounds(120, 70, 80, 20);
        print.addActionListener(this);
        add(print);

        cancel = new JButton("Cancel");
        cancel.setBounds(220, 70, 80, 20);
        cancel.addActionListener(this);
        add(cancel);

        setSize(900, 700);
        setLocation(300, 100);
        setVisible(true);
    }

    public static TableModel buildGroupedTableModel(ResultSet rs) throws SQLException {
        LinkedHashMap<String, Vector<String>> groupedData = new LinkedHashMap<>();
        int maxCourses = 0;

        while (rs.next()) {
            String rollno = rs.getString("rollno");
            String course = rs.getString("course");

            groupedData.putIfAbsent(rollno, new Vector<>());
            groupedData.get(rollno).add(course);
            maxCourses = Math.max(maxCourses, groupedData.get(rollno).size());
        }

        Vector<String> columnNames = new Vector<>();
        columnNames.add("Roll No");
        for (int i = 1; i <= maxCourses; i++) {
            columnNames.add("Course " + i);
        }

        Vector<Vector<Object>> data = new Vector<>();
        for (String rollno : groupedData.keySet()) {
            Vector<Object> row = new Vector<>();
            row.add(rollno);
            row.addAll(groupedData.get(rollno));

            while (row.size() < columnNames.size()) {
                row.add("");
            }

            data.add(row);
        }

        return new DefaultTableModel(data, columnNames);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            String query = "SELECT * FROM student_courses WHERE rollno = '" + crollno.getSelectedItem() + "' ";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                table.setModel(buildGroupedTableModel(rs));

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (ae.getSource() == print) {
            try {
                table.print();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new StudentCourseApplicationDetails();
    }
}